package app;

import db.myConnection;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class vip {

    Connection con = myConnection.getConnection();
    PreparedStatement ps;

    //insert data in student table
    public void insert(long id, String sname, String date, String gender, String email, String phone,
        String father, String mother, String address1, String address2, String ten, String twelve, String image_path,String rank,String fee) {
    String sql = "insert into student values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    try {
        ps = con.prepareStatement(sql);
        ps.setLong(1, id);  // Changed from setInt to setLong
        ps.setString(2, sname);
        ps.setString(3, date);
        ps.setString(4, gender);
        ps.setString(5, email);
        ps.setString(6, phone);
        ps.setString(7, father);
        ps.setString(8, mother);
        ps.setString(9, address1);
        ps.setString(10, address2);
        ps.setString(11, ten);
        ps.setString(12, twelve);
        ps.setString(13, image_path);
        ps.setString(14, rank);
        ps.setString(15, fee);

        if (ps.executeUpdate() > 0) {
            JOptionPane.showMessageDialog(null, "New student added Successfully");
        }

    } catch (SQLException ex) {
        Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, "Error adding student: " + ex.getMessage());
    }
}

    // check student email address is already exists
    public boolean isEmailExists(String email) {
        try {
            ps = con.prepareStatement("select * from student where emid = ?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    // check phone number is already exists
    public boolean isPhoneExists(String phone) {
        try {
            ps = con.prepareStatement("select * from student where pno = ?");
            ps.setString(1, phone);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }


    public boolean isIdExists(long id) {
    try {
        ps = con.prepareStatement("select * from student where id = ?");
        ps.setLong(1, id);  // Changed from setInt to setLong
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return true;
        }
    } catch (SQLException ex) {
        Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, "Error checking ID: " + ex.getMessage());
    }
    return false;
}

    //get all values of database of student table 
    public void getStudentValue(JTable table, String searchValue) {
    String sql = "select * from student where concat(id,stuname,emid,pno) like ? order by id desc";
    try {
        ps = con.prepareStatement(sql);
        ps.setString(1, "%" + searchValue + "%");
        ResultSet rs = ps.executeQuery();
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Clear existing rows before adding new ones
        Object[] row;
        while (rs.next()) {
            row = new Object[15];
            row[0] = rs.getLong(1);  // Changed from getInt to getLong
            row[1] = rs.getString(2);
            row[2] = rs.getString(3);
            row[3] = rs.getString(4);
            row[4] = rs.getString(5);
            row[5] = rs.getString(6);
            row[6] = rs.getString(7);
            row[7] = rs.getString(8);
            row[8] = rs.getString(9);
            row[9] = rs.getString(10);
            row[10] = rs.getString(11);
            row[11] = rs.getString(12);
            row[12] = rs.getString(13);
            row[13] = rs.getString(14);
            row[14] = rs.getString(15);
            model.addRow(row);
        }
    } catch (SQLException ex) {
        Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, "Error loading student data: " + ex.getMessage());
    }
}
// update student value
    
  public void update(long id, String name, String date, String gender, String email, String phone,
        String father, String mother, String address1, String address2, String ten, String twelve, 
        String image_path, String rank, String fee) {
    String sql = "UPDATE student SET stuname=?, dob=?, gen=?, emid=?, pno=?, "
            + "father=?, mother=?, ad=?, `add`=?, ten=?, twelve=?, image_path=?, rank=?, fee=? WHERE id=?";
    try {
        ps = con.prepareStatement(sql);
        ps.setString(1, name);
        ps.setString(2, date);
        ps.setString(3, gender);
        ps.setString(4, email);
        ps.setString(5, phone);
        ps.setString(6, father);
        ps.setString(7, mother);
        ps.setString(8, address1);
        ps.setString(9, address2);
        ps.setString(10, ten);
        ps.setString(11, twelve);
        ps.setString(12, image_path);
        ps.setString(13, rank);
        ps.setString(14, fee);
        ps.setLong(15, id);  // id should be the last parameter (15th)
        
        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, "Student data updated successfully");
        } else {
            JOptionPane.showMessageDialog(null, "No student found with ID: " + id);
        }
    } catch (SQLException ex) {
        Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, "Error updating student: " + ex.getMessage());
    }
}
// student data delete
public boolean delete(long id) {
    // Show confirmation dialog with proper options
    int confirmation = JOptionPane.showConfirmDialog(
        null, 
        "Are you sure you want to delete student with ID: " + id + "?",
        "Confirm Deletion",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.WARNING_MESSAGE);
    
    if (confirmation == JOptionPane.YES_OPTION) {
        try {
            ps = con.prepareStatement("DELETE FROM student WHERE id = ?");
            ps.setLong(1, id);  // Changed to setLong
            
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(
                    null, 
                    "Student data deleted successfully",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                return true;
            } else {
                JOptionPane.showMessageDialog(
                    null, 
                    "No student found with ID: " + id,
                    "Not Found",
                    JOptionPane.WARNING_MESSAGE);
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(
                null, 
                "Error deleting student: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    return false;
}

    
    // search student by the help of student id only
    public void getStudentById(JTable table, long studentId) {
    DefaultTableModel model = (DefaultTableModel) table.getModel();
    model.setRowCount(0); // Clear previous results

    String sql = "SELECT * FROM student WHERE id = ?";
    
    try {
        ps = con.prepareStatement(sql);
        ps.setLong(1, studentId); // Changed to setLong for exact match
        
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            Object[] row = new Object[15];
            row[0] = rs.getLong(1);    // Changed to getLong for Student ID
            row[1] = rs.getString(2);  // Student Name
            row[2] = rs.getString(3);   // D.O.B
            row[3] = rs.getString(4);   // Gender
            row[4] = rs.getString(5);   // Email ID
            row[5] = rs.getString(6);  // Phone number
            row[6] = rs.getString(7);  // Father Name
            row[7] = rs.getString(8);   // Mother Name
            row[8] = rs.getString(9);   // Address1
            row[9] = rs.getString(10);  // Address2
            row[10] = rs.getString(11); // 10th Percentage
            row[11] = rs.getString(12); // 12th Percentage
            row[12] = rs.getString(13); // Image Path
            row[13] = rs.getString(14);
            row[14] = rs.getString(15);
            model.addRow(row);
        } else {
            JOptionPane.showMessageDialog(null, "No student found with ID: " + studentId, 
                "Not Found", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
        Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, 
            "Database error while searching for student: " + ex.getMessage(), 
            "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (ps != null) ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
    
//sort student by rank 
    public void sortStudentsByRank(JTable table) {
    DefaultTableModel model = (DefaultTableModel) table.getModel();
    model.setRowCount(0); // Clear previous results

    // SQL to fetch all students and sort by rank (ascending - lower rank is better)
    String sql = "SELECT * FROM student ORDER BY CAST(`rank` AS UNSIGNED) ASC";
    
    try {
        ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Object[] row = new Object[15];
            row[0] = rs.getLong(1);    // Student ID
            row[1] = rs.getString(2);  // Student Name
            row[2] = rs.getString(3);  // D.O.B
            row[3] = rs.getString(4); // Gender
            row[4] = rs.getString(5);  // Email ID
            row[5] = rs.getString(6);  // Phone number
            row[6] = rs.getString(7);  // Father Name
            row[7] = rs.getString(8);  // Mother Name
            row[8] = rs.getString(9);  // Address1
            row[9] = rs.getString(10); // Address2
            row[10] = rs.getString(11); // 10th Percentage
            row[11] = rs.getString(12); // 12th Percentage
            row[12] = rs.getString(13); // Image Path
            row[13] = rs.getString(14); // CET/JEE Rank
            row[14] = rs.getString(15); // Payment
            model.addRow(row);
        }
    } catch (SQLException ex) {
        Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, 
            "Database error while sorting students by rank: " + ex.getMessage(), 
            "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (ps != null) ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
    //Sort by payments
    public void sortStudentsByPayment(JTable table) {
    DefaultTableModel model = (DefaultTableModel) table.getModel();
    model.setRowCount(0); // Clear previous results

    // SQL to fetch all students and sort by payment status
    // Assuming 'Payment' column contains values like 'Paid', 'Unpaid', 'Partial', etc.
    String sql = "SELECT * FROM student ORDER BY CAST(`fee` AS UNSIGNED) ASC";// Secondary sort by name
    
    try {
        ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Object[] row = new Object[15];
            row[0] = rs.getLong(1);    // Student ID
            row[1] = rs.getString(2);  // Student Name
            row[2] = rs.getString(3);  // D.O.B
            row[3] = rs.getString(4); // Gender
            row[4] = rs.getString(5);  // Email ID
            row[5] = rs.getString(6);  // Phone number
            row[6] = rs.getString(7);  // Father Name
            row[7] = rs.getString(8);  // Mother Name
            row[8] = rs.getString(9);  // Address1
            row[9] = rs.getString(10); // Address2
            row[10] = rs.getString(11); // 10th Percentage
            row[11] = rs.getString(12); // 12th Percentage
            row[12] = rs.getString(13); // Image Path
            row[13] = rs.getString(14); // CET/JEE Rank
            row[14] = rs.getString(15); // Payment
            model.addRow(row);
        }
    } catch (SQLException ex) {
        Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, 
            "Database error while sorting students by payment: " + ex.getMessage(), 
            "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try {
            if (ps != null) ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(vip.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

    
    
    
}
